/*
 Navicat Premium Data Transfer

 Source Server         : wxt
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : hello

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 23/04/2020 10:17:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for conversationrecord
-- ----------------------------
DROP TABLE IF EXISTS `conversationrecord`;
CREATE TABLE `conversationrecord`  (
  `conversationrecordid` int(8) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `botId` int(8) NULL DEFAULT NULL COMMENT '应用id',
  `userInputUtterance` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户输入语句',
  `replyUtterance` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '回复语句',
  `domainId` int(8) NULL DEFAULT NULL COMMENT '领域ID',
  `intentId` int(8) NULL DEFAULT NULL COMMENT '意图ID',
  `intentName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '意图名称',
  `timestamp` int(8) NULL DEFAULT NULL COMMENT '时间点',
  `resultType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '回复时的状态标识（ASK_INF：信息获取，例如“请问从哪个城市出发”，在此状态下，用户说的下一句话优先进入本意图进行有效信息抽取 RESULT：正常完成交互的阶段并给出回复 CONFIRM：期待确认）',
  `taskqueryid` int(8) NULL DEFAULT NULL COMMENT 'taskquery表主键',
  PRIMARY KEY (`conversationrecordid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of conversationrecord
-- ----------------------------
INSERT INTO `conversationrecord` VALUES (1, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 33);
INSERT INTO `conversationrecord` VALUES (2, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 33);
INSERT INTO `conversationrecord` VALUES (3, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 34);
INSERT INTO `conversationrecord` VALUES (4, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 34);
INSERT INTO `conversationrecord` VALUES (5, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 35);
INSERT INTO `conversationrecord` VALUES (6, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 35);
INSERT INTO `conversationrecord` VALUES (7, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 36);
INSERT INTO `conversationrecord` VALUES (8, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 36);
INSERT INTO `conversationrecord` VALUES (9, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 37);
INSERT INTO `conversationrecord` VALUES (10, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 37);
INSERT INTO `conversationrecord` VALUES (11, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 38);
INSERT INTO `conversationrecord` VALUES (12, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 38);
INSERT INTO `conversationrecord` VALUES (13, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 39);
INSERT INTO `conversationrecord` VALUES (14, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 39);
INSERT INTO `conversationrecord` VALUES (15, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 40);
INSERT INTO `conversationrecord` VALUES (16, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 40);
INSERT INTO `conversationrecord` VALUES (17, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 41);
INSERT INTO `conversationrecord` VALUES (18, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 41);
INSERT INTO `conversationrecord` VALUES (19, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 42);
INSERT INTO `conversationrecord` VALUES (20, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 42);
INSERT INTO `conversationrecord` VALUES (21, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 43);
INSERT INTO `conversationrecord` VALUES (22, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 43);
INSERT INTO `conversationrecord` VALUES (23, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 44);
INSERT INTO `conversationrecord` VALUES (24, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 44);
INSERT INTO `conversationrecord` VALUES (25, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 45);
INSERT INTO `conversationrecord` VALUES (26, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 45);
INSERT INTO `conversationrecord` VALUES (27, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 46);
INSERT INTO `conversationrecord` VALUES (28, 123, 'a', 'a', 123, 123, 'n', 123, 'ASK_INF', 46);

SET FOREIGN_KEY_CHECKS = 1;
