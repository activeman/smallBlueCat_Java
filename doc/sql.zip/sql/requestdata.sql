/*
 Navicat Premium Data Transfer

 Source Server         : wxt
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : hello

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 23/04/2020 10:17:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for requestdata
-- ----------------------------
DROP TABLE IF EXISTS `requestdata`;
CREATE TABLE `requestdata`  (
  `reuqestid` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `mapkey` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'map集合key值键值对',
  `mapvalue` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'map集合key对应的value值',
  `taskqueryid` int(8) NULL DEFAULT NULL COMMENT '外键 关联 taskquery',
  PRIMARY KEY (`reuqestid`) USING BTREE,
  INDEX `外键`(`taskqueryid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of requestdata
-- ----------------------------
INSERT INTO `requestdata` VALUES (1, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (2, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (3, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (4, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (5, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (6, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (7, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (8, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (9, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (10, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (11, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (12, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (13, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (14, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (15, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (16, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (17, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (18, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (19, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (20, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (21, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (22, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (23, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (24, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (25, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (26, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (27, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (28, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (29, '1', '金融秘书', 1);
INSERT INTO `requestdata` VALUES (30, '2', '金融管家', 1);
INSERT INTO `requestdata` VALUES (31, '1', '金融秘书', 26);
INSERT INTO `requestdata` VALUES (32, '2', '金融管家', 26);
INSERT INTO `requestdata` VALUES (33, '1', '金融秘书', 27);
INSERT INTO `requestdata` VALUES (34, '2', '金融管家', 27);
INSERT INTO `requestdata` VALUES (35, '1', '金融秘书', 28);
INSERT INTO `requestdata` VALUES (36, '2', '金融管家', 28);
INSERT INTO `requestdata` VALUES (37, '1', '金融秘书', 29);
INSERT INTO `requestdata` VALUES (38, '2', '金融管家', 29);
INSERT INTO `requestdata` VALUES (39, '1', '金融秘书', 30);
INSERT INTO `requestdata` VALUES (40, '2', '金融管家', 30);
INSERT INTO `requestdata` VALUES (41, '1', '金融秘书', 31);
INSERT INTO `requestdata` VALUES (42, '2', '金融管家', 31);
INSERT INTO `requestdata` VALUES (43, '1', '金融秘书', 32);
INSERT INTO `requestdata` VALUES (44, '2', '金融管家', 32);
INSERT INTO `requestdata` VALUES (45, '1', '金融秘书', 33);
INSERT INTO `requestdata` VALUES (46, '2', '金融管家', 33);
INSERT INTO `requestdata` VALUES (47, '1', '金融秘书', 34);
INSERT INTO `requestdata` VALUES (48, '1', '金融秘书', 35);
INSERT INTO `requestdata` VALUES (49, '1', '金融秘书', 36);
INSERT INTO `requestdata` VALUES (50, '1', '金融秘书', 37);
INSERT INTO `requestdata` VALUES (51, '1', '金融秘书', 38);
INSERT INTO `requestdata` VALUES (52, '1', '金融秘书', 39);
INSERT INTO `requestdata` VALUES (53, '1', '金融秘书', 40);
INSERT INTO `requestdata` VALUES (54, '1', '金融秘书', 41);
INSERT INTO `requestdata` VALUES (55, '1', '金融秘书', 42);
INSERT INTO `requestdata` VALUES (56, '1', '金融秘书', 43);
INSERT INTO `requestdata` VALUES (57, '1', '金融秘书', 44);
INSERT INTO `requestdata` VALUES (58, '1', '金融秘书', 45);
INSERT INTO `requestdata` VALUES (59, '1', '金融秘书', 46);

SET FOREIGN_KEY_CHECKS = 1;
