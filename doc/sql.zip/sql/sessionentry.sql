/*
 Navicat Premium Data Transfer

 Source Server         : wxt
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : hello

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 23/04/2020 10:17:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sessionentry
-- ----------------------------
DROP TABLE IF EXISTS `sessionentry`;
CREATE TABLE `sessionentry`  (
  `sessionentryid` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `timeToLive` int(8) NULL DEFAULT NULL,
  `liveTime` int(8) NULL DEFAULT NULL,
  `timeStamp` int(8) NULL DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sessionkey` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'taskquery实体的sesssion的map集合key',
  `taskQueryId` int(8) NULL DEFAULT NULL COMMENT 'taskquery主键',
  PRIMARY KEY (`sessionentryid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sessionentry
-- ----------------------------
INSERT INTO `sessionentry` VALUES (1, 1, 0, 123, 'ss1', 'ss1', 35);
INSERT INTO `sessionentry` VALUES (2, 1, 0, 123, 'ss1', 'ss1', 36);
INSERT INTO `sessionentry` VALUES (3, 1, 1, 123, 'ss1', 'ss1', 37);
INSERT INTO `sessionentry` VALUES (4, 1, 1, 123, 'ss1', 'ss1', 38);
INSERT INTO `sessionentry` VALUES (5, 1, 1, 123, 'ss1', 'ss1', 39);
INSERT INTO `sessionentry` VALUES (6, 1, 1, 123, 'ss1', 'ss1', 40);
INSERT INTO `sessionentry` VALUES (7, 1, 1, 123, 'ss1', 'ss1', 41);
INSERT INTO `sessionentry` VALUES (8, 1, 1, 123, 'ss1', 'ss1', 42);
INSERT INTO `sessionentry` VALUES (9, 1, 1, 123, 'ss1', 'ss1', 43);
INSERT INTO `sessionentry` VALUES (10, 2, 2, 345, 'ss2', 'ss2', 43);
INSERT INTO `sessionentry` VALUES (11, 1, 1, 123, 'ss1', 'ss1', 44);
INSERT INTO `sessionentry` VALUES (12, 2, 2, 345, 'ss2', 'ss2', 44);
INSERT INTO `sessionentry` VALUES (13, 1, 1, 123, 'ss1', 'ss1', 45);
INSERT INTO `sessionentry` VALUES (14, 1, 1, 123, 'ss1', 'ss1', 46);
INSERT INTO `sessionentry` VALUES (15, 2, 2, 345, 'ss2', 'ss2', 46);

SET FOREIGN_KEY_CHECKS = 1;
