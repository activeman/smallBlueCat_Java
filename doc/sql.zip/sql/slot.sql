/*
 Navicat Premium Data Transfer

 Source Server         : wxt
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : hello

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 23/04/2020 10:17:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for slot
-- ----------------------------
DROP TABLE IF EXISTS `slot`;
CREATE TABLE `slot`  (
  `soltentityid` int(8) NOT NULL AUTO_INCREMENT COMMENT 'soltentity主键id',
  `intentParameterId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '意图参数ID',
  `intentParameterName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '意图参数名->意图的名字',
  `originalValue` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '原始句子中抽取出来的未做处理的slot值',
  `standardValue` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '原始slot归一化后的值',
  `liveTime` int(11) NULL DEFAULT NULL COMMENT '该slot已生存时间（会话轮数）',
  `createTimeStamp` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '该slot产生的时间点',
  `slotName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'slot名称',
  `slotValue` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'slot值',
  `taskqueryid` int(8) NULL DEFAULT NULL COMMENT 'taskQuery表主键',
  PRIMARY KEY (`soltentityid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of slot
-- ----------------------------
INSERT INTO `slot` VALUES (1, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (2, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (3, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (4, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (5, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (6, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 1);
INSERT INTO `slot` VALUES (7, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 33);
INSERT INTO `slot` VALUES (8, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 33);
INSERT INTO `slot` VALUES (9, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 34);
INSERT INTO `slot` VALUES (10, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 34);
INSERT INTO `slot` VALUES (11, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 35);
INSERT INTO `slot` VALUES (12, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 35);
INSERT INTO `slot` VALUES (13, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 36);
INSERT INTO `slot` VALUES (14, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 36);
INSERT INTO `slot` VALUES (15, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 37);
INSERT INTO `slot` VALUES (16, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 37);
INSERT INTO `slot` VALUES (17, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 38);
INSERT INTO `slot` VALUES (18, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 38);
INSERT INTO `slot` VALUES (19, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 39);
INSERT INTO `slot` VALUES (20, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 39);
INSERT INTO `slot` VALUES (21, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 40);
INSERT INTO `slot` VALUES (22, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 40);
INSERT INTO `slot` VALUES (23, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 41);
INSERT INTO `slot` VALUES (24, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 41);
INSERT INTO `slot` VALUES (25, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 42);
INSERT INTO `slot` VALUES (26, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 42);
INSERT INTO `slot` VALUES (27, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 43);
INSERT INTO `slot` VALUES (28, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 43);
INSERT INTO `slot` VALUES (29, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 44);
INSERT INTO `slot` VALUES (30, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 44);
INSERT INTO `slot` VALUES (31, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 45);
INSERT INTO `slot` VALUES (32, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 45);
INSERT INTO `slot` VALUES (33, '1234', 'a', 'a', 'a', 1, '1234', 'a', 'a', 46);
INSERT INTO `slot` VALUES (34, '1234', 'b', 'b', 'b', 1, '1234', 'a', 'a', 46);

SET FOREIGN_KEY_CHECKS = 1;
