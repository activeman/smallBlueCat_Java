/*
 Navicat Premium Data Transfer

 Source Server         : wxt
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : hello

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 23/04/2020 10:17:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for taskquery
-- ----------------------------
DROP TABLE IF EXISTS `taskquery`;
CREATE TABLE `taskquery`  (
  `taskQueryId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `sessionId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `utterance` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户输入语句',
  `skillId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '技能ID',
  `skillName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '技能名称',
  `token` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '技能鉴权token，可以不需要，如果有安全需求需要配置',
  `intentId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '意图ID',
  `intentName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '意图名称',
  `botId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '应用ID',
  `domainId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '领域ID',
  PRIMARY KEY (`taskQueryId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of taskquery
-- ----------------------------
INSERT INTO `taskquery` VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `taskquery` VALUES (7, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (8, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (9, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (10, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (11, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (12, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (13, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (14, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (15, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (16, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (17, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (18, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (19, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (21, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (22, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (23, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (24, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (25, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (26, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (27, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (28, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (29, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (30, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (31, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (32, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (33, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (34, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (35, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (36, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (37, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (38, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (39, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (40, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (41, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (42, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (43, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (44, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (45, '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `taskquery` VALUES (46, '1', '1', '1', '1', '1', '1', '1', '1', '1');

SET FOREIGN_KEY_CHECKS = 1;
